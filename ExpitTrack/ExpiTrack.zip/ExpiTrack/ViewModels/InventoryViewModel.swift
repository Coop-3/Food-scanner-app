import Foundation
import Combine
import UIKit

@MainActor
final class InventoryViewModel: ObservableObject {
    @Published private(set) var items: [FoodItem] = []
    @Published var sortOption: InventorySortOption = .recentlyAdded
    @Published var searchText = ""

    private let storage = StorageService.shared
    private let imageStorage = ImageStorageService.shared
    private let fileName = "food_items.json"

    var allItems: [FoodItem] {
        items
    }

    var filteredItems: [FoodItem] {
        let trimmed = searchText.trimmingCharacters(in: .whitespacesAndNewlines)

        let baseItems: [FoodItem]
        if trimmed.isEmpty {
            baseItems = items
        } else {
            baseItems = items.filter {
                $0.name.localizedCaseInsensitiveContains(trimmed) ||
                $0.quantity.localizedCaseInsensitiveContains(trimmed) ||
                $0.storageLocation.rawValue.localizedCaseInsensitiveContains(trimmed)
            }
        }

        switch sortOption {
        case .recentlyAdded:
            return baseItems.sorted { $0.createdAt > $1.createdAt }
        case .expirationDate:
            return baseItems.sorted { $0.expirationDate < $1.expirationDate }
        }
    }

    var activeItems: [FoodItem] {
        filteredItems.filter { FoodStatus.status(for: $0.expirationDate) != .expired }
    }

    var expiredItems: [FoodItem] {
        filteredItems.filter { FoodStatus.status(for: $0.expirationDate) == .expired }
    }

    var expiringSoonItems: [FoodItem] {
        filteredItems.filter { FoodStatus.status(for: $0.expirationDate) == .expiringSoon }
    }

    var expiringSoonCount: Int {
        allItems.filter { FoodStatus.status(for: $0.expirationDate) == .expiringSoon }.count
    }

    var totalItemCount: Int {
        allItems.count
    }

    var expiredCount: Int {
        allItems.filter { FoodStatus.status(for: $0.expirationDate) == .expired }.count
    }

    var summaryBannerTitle: String {
        if expiringSoonCount == 0 {
            return "Nothing is expiring soon"
        } else if expiringSoonCount == 1 {
            return "1 item is expiring within 3 days"
        } else {
            return "\(expiringSoonCount) items are expiring within 3 days"
        }
    }

    var summaryBannerSubtitle: String {
        if expiringSoonCount == 0 {
            return "You're in good shape. Keep tracking items to stay ahead of expiration dates."
        } else {
            return "Review these items soon or add them to your grocery list when needed."
        }
    }

    init() {
        reload()
    }

    func reload() {
        items = storage.load([FoodItem].self, from: fileName, defaultValue: [])
    }

    func addItem(
        name: String,
        quantity: String,
        expirationDate: Date,
        storageLocation: StorageLocation,
        image: UIImage?,
        savePhotoTemplate: Bool
    ) {
        let imageFileName = image.flatMap { imageStorage.saveImage($0) }

        let item = FoodItem(
            name: name,
            quantity: quantity,
            expirationDate: expirationDate,
            storageLocation: storageLocation,
            imageFileName: imageFileName,
            savedTemplateName: (savePhotoTemplate && imageFileName != nil) ? name : nil
        )

        items.append(item)
        persist()
    }

    func updateItem(
        _ item: FoodItem,
        name: String,
        quantity: String,
        expirationDate: Date,
        storageLocation: StorageLocation,
        newImage: UIImage?,
        keepExistingImage: Bool,
        savePhotoTemplate: Bool
    ) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }

        var updated = item
        updated.name = name
        updated.quantity = quantity
        updated.expirationDate = expirationDate
        updated.storageLocation = storageLocation
        updated.updatedAt = Date()

        if let newImage {
            imageStorage.deleteImage(fileName: item.imageFileName)
            updated.imageFileName = imageStorage.saveImage(newImage)
        } else if !keepExistingImage {
            imageStorage.deleteImage(fileName: item.imageFileName)
            updated.imageFileName = nil
        }

        updated.savedTemplateName = (savePhotoTemplate && updated.imageFileName != nil) ? name : nil

        items[index] = updated
        persist()
    }

    func deleteItem(_ item: FoodItem) {
        imageStorage.deleteImage(fileName: item.imageFileName)
        items.removeAll { $0.id == item.id }
        persist()
    }

    func image(for item: FoodItem) -> UIImage? {
        imageStorage.loadImage(fileName: item.imageFileName)
    }

    func savedTemplateItem(for rawName: String) -> FoodItem? {
        let normalized = normalize(rawName)

        return items
            .filter {
                guard let templateName = $0.savedTemplateName,
                      $0.imageFileName != nil else {
                    return false
                }

                return normalize(templateName) == normalized
            }
            .sorted { $0.updatedAt > $1.updatedAt }
            .first
    }

    func savedTemplateImage(for rawName: String) -> UIImage? {
        guard let templateItem = savedTemplateItem(for: rawName) else { return nil }
        return image(for: templateItem)
    }

    private func normalize(_ text: String) -> String {
        text
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
    }

    private func persist() {
        storage.save(items, as: fileName)
    }
}

enum InventorySortOption: String, CaseIterable, Identifiable {
    case recentlyAdded = "Recently Added"
    case expirationDate = "Expiration Date"

    var id: String { rawValue }
}
