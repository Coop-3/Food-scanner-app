import Foundation
import Combine

@MainActor
final class AuthViewModel: ObservableObject {
    @Published var username = ""
    @Published var password = ""
    @Published var isLoggedIn = false
    @Published var errorMessage = ""
    @Published var isCreateAccountMode = false

    private let authService = AuthService.shared

    init() {
        isLoggedIn = authService.isLoggedIn()
    }

    func submit() {
        errorMessage = ""
        let result: Result<Void, AuthError>

        if isCreateAccountMode || !authService.hasAccount() {
            result = authService.signUp(username: username, password: password)
        } else {
            result = authService.login(username: username, password: password)
        }

        switch result {
        case .success:
            isLoggedIn = true
            username = ""
            password = ""
        case .failure(let error):
            errorMessage = error.localizedDescription
        }
    }

    func logout() {
        authService.logout()
        isLoggedIn = false
    }
}
