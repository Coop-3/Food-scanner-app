import Foundation
import Combine

@MainActor
final class NotificationCenterViewModel: ObservableObject {
    @Published private(set) var notifications: [AppNotification] = []

    func reload(from items: [FoodItem]) {
        notifications = items.compactMap { item in
            let status = FoodStatus.status(for: item.expirationDate)
            switch status {
            case .fresh:
                return nil
            case .expiringSoon:
                return AppNotification(
                    itemID: item.id,
                    itemName: item.name,
                    expirationDate: item.expirationDate,
                    message: "This item is expiring within 3 days.",
                    status: .expiringSoon
                )
            case .expired:
                return AppNotification(
                    itemID: item.id,
                    itemName: item.name,
                    expirationDate: item.expirationDate,
                    message: "This item has expired.",
                    status: .expired
                )
            }
        }
        .sorted { $0.expirationDate < $1.expirationDate }
    }
}
