import Foundation
import Combine
import SwiftUI

@MainActor
final class GroceryListViewModel: ObservableObject {
    @Published private(set) var items: [GroceryListItem] = []
    @Published var suggestedItems: [FoodItem] = []

    private let storage = StorageService.shared
    private let fileName = "grocery_list.json"
    private let promptSeenKey = "expitrack.promptSeenDate"

    init() {
        load()
    }

    func load() {
        items = storage.load([GroceryListItem].self, from: fileName, defaultValue: [])
    }

    func refreshSuggestions(from inventoryItems: [FoodItem]) {
        suggestedItems = inventoryItems.filter {
            FoodStatus.status(for: $0.expirationDate) == .expiringSoon
        }
        .filter { candidate in
            !items.contains {
                if let sourceItemID = $0.sourceItemID {
                    return sourceItemID == candidate.id
                }

                return $0.name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                    == candidate.name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            }
        }
    }

    func addPendingSuggestions() {
        let expiringSoonItems = suggestedItems.filter {
            FoodStatus.status(for: $0.expirationDate) == .expiringSoon
        }

        let newItems = expiringSoonItems.map {
            GroceryListItem(name: $0.name, sourceItemID: $0.id)
        }

        items.append(contentsOf: newItems)
        suggestedItems.removeAll()
        markPromptSeenToday()
        persist()
    }

    func dismissSuggestionsForToday() {
        markPromptSeenToday()
    }

    var shouldShowPrompt: Bool {
        !suggestedItems.isEmpty && !hasSeenPromptToday()
    }

    func addManualItem(name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        items.append(GroceryListItem(name: trimmed))
        persist()
    }

    func toggle(_ item: GroceryListItem) {
        guard let index = items.firstIndex(where: { $0.id == item.id }) else { return }
        items[index].isChecked.toggle()
        persist()
    }

    func delete(at offsets: IndexSet) {
        items.remove(atOffsets: offsets)
        persist()
    }

    private func hasSeenPromptToday() -> Bool {
        guard let storedDate = UserDefaults.standard.object(forKey: promptSeenKey) as? Date else {
            return false
        }
        return Calendar.current.isDateInToday(storedDate)
    }

    private func markPromptSeenToday() {
        UserDefaults.standard.set(Date(), forKey: promptSeenKey)
    }

    private func persist() {
        storage.save(items, as: fileName)
    }
}
