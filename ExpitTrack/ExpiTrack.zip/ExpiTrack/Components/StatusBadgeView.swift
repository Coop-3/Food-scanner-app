import SwiftUI

struct StatusBadgeView: View {
    let status: FoodStatus

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: status.systemImage)
            Text(status.rawValue)
                .fontWeight(.semibold)
        }
        .font(.caption)
        .foregroundStyle(status.color)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(status.color.opacity(0.12))
        .clipShape(Capsule())
    }
}
