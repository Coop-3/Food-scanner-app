import SwiftUI
import UIKit

struct ItemCardView: View {
    let item: FoodItem
    let image: UIImage?

    private var status: FoodStatus {
        FoodStatus.status(for: item.expirationDate)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Group {
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                } else {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color(.systemGray6))

                        Image(systemName: "photo")
                            .font(.system(size: 30))
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .frame(height: 120)
            .frame(maxWidth: .infinity)
            .clipShape(RoundedRectangle(cornerRadius: 16))

            Text(item.name)
                .font(.headline)
                .lineLimit(1)

            Text(item.quantity)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .lineLimit(1)

            Label(item.storageLocation.rawValue, systemImage: item.storageLocation.systemImage)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)

            Text(DateHelper.expirationText(for: item.expirationDate))
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(status.color)

            StatusBadgeView(status: status)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}
