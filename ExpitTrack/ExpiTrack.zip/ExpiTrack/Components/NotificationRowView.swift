import SwiftUI

struct NotificationRowView: View {
    let notification: AppNotification

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: notification.status.systemImage)
                .foregroundStyle(notification.status.color)
                .font(.title3)

            VStack(alignment: .leading, spacing: 6) {
                Text(notification.itemName)
                    .font(.headline)
                Text(notification.message)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Text("Expiration: \(DateHelper.displayFormatter.string(from: notification.expirationDate))")
                    .font(.footnote)
                    .foregroundStyle(notification.status.color)
            }
        }
        .padding(.vertical, 6)
    }
}
