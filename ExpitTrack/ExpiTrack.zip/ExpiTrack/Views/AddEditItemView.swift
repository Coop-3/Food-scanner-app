import SwiftUI
import PhotosUI
import UIKit

struct AddEditItemView: View {
    enum Mode {
        case add
        case edit(FoodItem)

        var title: String {
            switch self {
            case .add:
                return "Add Item"
            case .edit:
                return "Edit Item"
            }
        }
    }

    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var inventoryViewModel: InventoryViewModel

    let mode: Mode

    @State private var name = ""
    @State private var quantity = "1"
    @State private var expirationDate = Date()
    @State private var storageLocation: StorageLocation = .fridge
    @State private var manualDateText = ""
    @State private var selectedImage: UIImage?
    @State private var existingImage: UIImage?
    @State private var keepExistingImage = true
    @State private var showCamera = false
    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var saveTemplate = false
    @State private var showValidationAlert = false
    @State private var validationMessage = ""
    @State private var showTemplateAppliedMessage = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Item Details") {
                    TextField("Food name", text: $name)
                    TextField("Quantity", text: $quantity)

                    Picker("Location", selection: $storageLocation) {
                        ForEach(StorageLocation.allCases) { location in
                            Label(location.rawValue, systemImage: location.systemImage)
                                .tag(location)
                        }
                    }
                }

                if case .add = mode,
                   let templateItem = matchingTemplate,
                   let templateImage = matchingTemplateImage,
                   selectedImage == nil {
                    Section("Saved Photo Found") {
                        HStack(spacing: 12) {
                            Image(uiImage: templateImage)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 64, height: 64)
                                .clipShape(RoundedRectangle(cornerRadius: 12))

                            VStack(alignment: .leading, spacing: 4) {
                                Text("Use saved photo for \(templateItem.name)?")
                                    .font(.headline)
                                Text("This was saved from a previous entry.")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }

                        Button("Use Saved Photo") {
                            selectedImage = templateImage
                            keepExistingImage = false
                            saveTemplate = true
                            showTemplateAppliedMessage = true
                        }
                    }
                }

                Section("Expiration Date") {
                    DatePicker("Select Date", selection: $expirationDate, displayedComponents: .date)

                    TextField("Or type a date (MM/DD/YYYY)", text: $manualDateText)
                        .keyboardType(.numbersAndPunctuation)
                        .onChange(of: manualDateText) { _, newValue in
                            if let parsed = CommonDateParser.parse(newValue) {
                                expirationDate = parsed
                            }
                        }

                    Text("Accepted formats: 4/22/2026, 04/22/26, 2026-04-22")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Photo") {
                    HStack(spacing: 16) {
                        PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                            Label("Choose Photo", systemImage: "photo.on.rectangle")
                        }
                        .onChange(of: selectedPhotoItem) { _, newItem in
                            loadImage(from: newItem)
                        }

                        Button {
                            showCamera = true
                        } label: {
                            Label("Use Camera", systemImage: "camera")
                        }
                    }

                    if let previewImage {
                        Image(uiImage: previewImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: 180)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }

                    if case .edit = mode, existingImage != nil || selectedImage != nil {
                        Toggle("Keep existing image", isOn: $keepExistingImage)
                    }

                    Toggle("Save this photo for future items with the same name", isOn: $saveTemplate)
                }

                if showTemplateAppliedMessage {
                    Section {
                        Label("Saved photo applied to this new item.", systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                    }
                }
            }
            .navigationTitle(mode.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }

                ToolbarItem(placement: .topBarTrailing) {
                    Button("Save") {
                        saveItem()
                    }
                }
            }
            .sheet(isPresented: $showCamera) {
                ImagePicker(sourceType: .camera, selectedImage: $selectedImage)
            }
            .alert("Unable to Save", isPresented: $showValidationAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(validationMessage)
            }
            .onAppear(perform: configure)
        }
    }

    private var previewImage: UIImage? {
        selectedImage ?? (keepExistingImage ? existingImage : nil)
    }

    private var matchingTemplate: FoodItem? {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return inventoryViewModel.savedTemplateItem(for: trimmed)
    }

    private var matchingTemplateImage: UIImage? {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return inventoryViewModel.savedTemplateImage(for: trimmed)
    }

    private func configure() {
        switch mode {
        case .add:
            break

        case .edit(let item):
            name = item.name
            quantity = item.quantity
            expirationDate = item.expirationDate
            storageLocation = item.storageLocation
            manualDateText = DateHelper.displayFormatter.string(from: item.expirationDate)
            existingImage = inventoryViewModel.image(for: item)
            keepExistingImage = item.imageFileName != nil
            saveTemplate = item.savedTemplateName != nil
        }
    }

    private func loadImage(from photoItem: PhotosPickerItem?) {
        guard let photoItem else { return }

        Task {
            if let data = try? await photoItem.loadTransferable(type: Data.self),
               let image = UIImage(data: data) {
                await MainActor.run {
                    selectedImage = image
                    keepExistingImage = false
                    showTemplateAppliedMessage = false
                }
            }
        }
    }

    private func saveItem() {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedQuantity = quantity.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedName.isEmpty else {
            validationMessage = "Enter a food name."
            showValidationAlert = true
            return
        }

        guard !trimmedQuantity.isEmpty else {
            validationMessage = "Enter a quantity."
            showValidationAlert = true
            return
        }

        switch mode {
        case .add:
            inventoryViewModel.addItem(
                name: trimmedName,
                quantity: trimmedQuantity,
                expirationDate: expirationDate,
                storageLocation: storageLocation,
                image: selectedImage,
                savePhotoTemplate: saveTemplate
            )

        case .edit(let item):
            inventoryViewModel.updateItem(
                item,
                name: trimmedName,
                quantity: trimmedQuantity,
                expirationDate: expirationDate,
                storageLocation: storageLocation,
                newImage: selectedImage,
                keepExistingImage: keepExistingImage,
                savePhotoTemplate: saveTemplate
            )
        }

        dismiss()
    }
}
