import SwiftUI

struct NotificationsView: View {
    @EnvironmentObject private var notificationViewModel: NotificationCenterViewModel

    var body: some View {
        NavigationStack {
            List {
                if notificationViewModel.notifications.isEmpty {
                    ContentUnavailableView(
                        "No Notifications",
                        systemImage: "bell.slash",
                        description: Text("Items that are expired or expiring soon will appear here.")
                    )
                } else {
                    ForEach(notificationViewModel.notifications) { notification in
                        NotificationRowView(notification: notification)
                    }
                }
            }
            .navigationTitle("Notifications")
        }
    }
}
