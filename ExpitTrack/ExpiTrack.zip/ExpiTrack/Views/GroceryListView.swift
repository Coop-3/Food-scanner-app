import SwiftUI

struct GroceryListView: View {
    @EnvironmentObject private var groceryListViewModel: GroceryListViewModel
    @State private var newItemName = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                HStack {
                    TextField("Add grocery list item", text: $newItemName)
                        .textFieldStyle(.roundedBorder)
                    Button("Add") {
                        groceryListViewModel.addManualItem(name: newItemName)
                        newItemName = ""
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(.horizontal)

                if groceryListViewModel.items.isEmpty {
                    ContentUnavailableView(
                        "No Grocery List Items",
                        systemImage: "cart",
                        description: Text("Expiring items can be added from the dashboard prompt, or add one manually here.")
                    )
                } else {
                    List {
                        ForEach(groceryListViewModel.items) { item in
                            Button {
                                groceryListViewModel.toggle(item)
                            } label: {
                                HStack {
                                    Image(systemName: item.isChecked ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(item.isChecked ? .green : .secondary)
                                    Text(item.name)
                                        .strikethrough(item.isChecked)
                                        .foregroundStyle(item.isChecked ? .secondary : .primary)
                                    Spacer()
                                }
                            }
                            .buttonStyle(.plain)
                        }
                        .onDelete(perform: groceryListViewModel.delete)
                    }
                    .listStyle(.insetGrouped)
                }
            }
            .navigationTitle("Grocery List")
        }
    }
}
