import Foundation
import UIKit

final class ImageStorageService {
    static let shared = ImageStorageService()
    private init() {}

    private var directoryURL: URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let directory = documents.appendingPathComponent("ItemImages", isDirectory: true)
        if !FileManager.default.fileExists(atPath: directory.path) {
            try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        }
        return directory
    }

    func saveImage(_ image: UIImage) -> String? {
        let fileName = "\(UUID().uuidString).jpg"
        let url = directoryURL.appendingPathComponent(fileName)
        guard let data = image.jpegData(compressionQuality: 0.85) else { return nil }

        do {
            try data.write(to: url, options: [.atomic])
            return fileName
        } catch {
            print("Image save failed: \(error.localizedDescription)")
            return nil
        }
    }

    func loadImage(fileName: String?) -> UIImage? {
        guard let fileName else { return nil }
        let url = directoryURL.appendingPathComponent(fileName)
        guard FileManager.default.fileExists(atPath: url.path) else { return nil }
        return UIImage(contentsOfFile: url.path)
    }

    func deleteImage(fileName: String?) {
        guard let fileName else { return }
        let url = directoryURL.appendingPathComponent(fileName)
        try? FileManager.default.removeItem(at: url)
    }
}
