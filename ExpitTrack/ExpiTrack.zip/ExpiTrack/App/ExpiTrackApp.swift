import SwiftUI

@main
struct ExpiTrackApp: App {
    @StateObject private var authViewModel = AuthViewModel()
    @StateObject private var inventoryViewModel = InventoryViewModel()
    @StateObject private var groceryListViewModel = GroceryListViewModel()
    @StateObject private var notificationViewModel = NotificationCenterViewModel()

    init() {
        NotificationService.shared.requestAuthorization()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(authViewModel)
                .environmentObject(inventoryViewModel)
                .environmentObject(groceryListViewModel)
                .environmentObject(notificationViewModel)
        }
    }
}
