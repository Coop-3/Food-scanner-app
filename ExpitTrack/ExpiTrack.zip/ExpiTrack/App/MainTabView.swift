import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Inventory", systemImage: "house.fill")
                }

            GroceryListView()
                .tabItem {
                    Label("Grocery List", systemImage: "cart.fill")
                }

            NotificationsView()
                .tabItem {
                    Label("Notifications", systemImage: "bell.fill")
                }
        }
        .tint(.green)
    }
}
