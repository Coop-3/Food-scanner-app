import SwiftUI

struct RootView: View {
    @EnvironmentObject private var authViewModel: AuthViewModel
    @EnvironmentObject private var inventoryViewModel: InventoryViewModel
    @EnvironmentObject private var groceryListViewModel: GroceryListViewModel
    @EnvironmentObject private var notificationViewModel: NotificationCenterViewModel

    @State private var showGroceryPrompt = false

    var body: some View {
        Group {
            if authViewModel.isLoggedIn {
                HomeView()
                    .onAppear {
                        inventoryViewModel.reload()
                        groceryListViewModel.load()
                        groceryListViewModel.refreshSuggestions(from: inventoryViewModel.allItems)
                        showGroceryPrompt = groceryListViewModel.shouldShowPrompt
                    }
                    .onChange(of: inventoryViewModel.allItems.count) { _, _ in
                        groceryListViewModel.refreshSuggestions(from: inventoryViewModel.allItems)
                        showGroceryPrompt = groceryListViewModel.shouldShowPrompt
                    }
                    .alert("Add expiring items to grocery list?", isPresented: $showGroceryPrompt) {
                        Button("No", role: .cancel) {
                            groceryListViewModel.dismissSuggestionsForToday()
                        }

                        Button("Yes") {
                            groceryListViewModel.addPendingSuggestions()
                        }
                    } message: {
                        Text("Only items expiring within 3 days will be added to the grocery list.")
                    }
            } else {
                LoginView()
            }
        }
    }
}
