import Foundation

struct GroceryListItem: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var sourceItemID: UUID?
    var createdAt: Date
    var isChecked: Bool

    init(id: UUID = UUID(), name: String, sourceItemID: UUID? = nil, createdAt: Date = Date(), isChecked: Bool = false) {
        self.id = id
        self.name = name
        self.sourceItemID = sourceItemID
        self.createdAt = createdAt
        self.isChecked = isChecked
    }
}
