import Foundation

struct AppNotification: Identifiable, Codable, Equatable {
    let id: UUID
    let itemID: UUID
    let itemName: String
    let expirationDate: Date
    let message: String
    let status: FoodStatus
    let createdAt: Date

    init(id: UUID = UUID(), itemID: UUID, itemName: String, expirationDate: Date, message: String, status: FoodStatus, createdAt: Date = Date()) {
        self.id = id
        self.itemID = itemID
        self.itemName = itemName
        self.expirationDate = expirationDate
        self.message = message
        self.status = status
        self.createdAt = createdAt
    }
}
