import Foundation

struct FoodItem: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var quantity: String
    var expirationDate: Date
    var storageLocation: StorageLocation
    var imageFileName: String?
    var createdAt: Date
    var updatedAt: Date
    var savedTemplateName: String?

    init(
        id: UUID = UUID(),
        name: String,
        quantity: String,
        expirationDate: Date,
        storageLocation: StorageLocation = .fridge,
        imageFileName: String? = nil,
        createdAt: Date = Date(),
        updatedAt: Date = Date(),
        savedTemplateName: String? = nil
    ) {
        self.id = id
        self.name = name
        self.quantity = quantity
        self.expirationDate = expirationDate
        self.storageLocation = storageLocation
        self.imageFileName = imageFileName
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.savedTemplateName = savedTemplateName
    }
}
