import Foundation

struct UserAccount: Codable, Equatable {
    var username: String
    var password: String
}
