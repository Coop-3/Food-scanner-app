import Foundation

enum StorageLocation: String, Codable, CaseIterable, Identifiable {
    case fridge = "Fridge"
    case freezer = "Freezer"
    case pantry = "Pantry"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .fridge:
            return "refrigerator"
        case .freezer:
            return "snowflake"
        case .pantry:
            return "cabinet"
        }
    }
}
